## ------------------------------------------------------------------------
# install.packages("")

## ----message=FALSE-------------------------------------------------------
require(csDEX)

design.file = system.file("extdata/metadata.tsv", 
    package="csDEX", mustWork=TRUE)
data.dir.psi = system.file("extdata/psi", 
    package="csDEX", mustWork=TRUE)
data.dir.count = system.file("extdata/count", 
    package="csDEX", mustWork=TRUE)

## ---- message=FALSE------------------------------------------------------
cdx = csDEXdataSet(data.dir=data.dir.psi, 
                   design.file=design.file, 
                   type="PSI",
                   aggregation=mean)

## ----eval=FALSE----------------------------------------------------------
#  result = csd.testForDEU(cdx,
#      workers=1,
#      tmp.dir=NULL)

## ----message=FALSE-------------------------------------------------------
cdx = csDEXdataSet(data.dir=data.dir.count, 
    design.file=design.file, 
    type="count")

## ------------------------------------------------------------------------
cdx = estimateSizeFactors(cdx)

## ----eval=FALSE----------------------------------------------------------
#  exprData(cdx, normalized=TRUE)

## ------------------------------------------------------------------------
cdx = estimateDispersions(cdx)

## ---- results=1:10-------------------------------------------------------
cdx = estimateGeneCPM(cdx)
cpmData(cdx)

## ----eval=FALSE----------------------------------------------------------
#  result = csd.testForDEU(cdx, workers=1, tmp.dir=NULL, min.cpm=1)

